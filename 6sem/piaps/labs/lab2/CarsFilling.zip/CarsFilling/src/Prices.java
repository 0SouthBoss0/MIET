public class Prices {
    public static final int ADULT_TAXI_KM = 30;
    public static final int ADULT_BUS_TICKET = 63;
    public static final int CHILD_TAXI_KM = 40;
    public static final int CHILD_BUS_TICKET = 37;
    public static final int PRIVILEGE_BUS_TICKET = 20;

}
