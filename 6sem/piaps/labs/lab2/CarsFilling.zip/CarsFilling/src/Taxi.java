public class Taxi extends Vehicle {
    private boolean hasChildSeat;

    public Taxi() {
        super(4);
        this.hasChildSeat = false;
    }

    void setChildSeat() {
        this.hasChildSeat = true;
        System.out.println("Детское кресло установлено!");
    }

    boolean getHasChildSeat() {
        return this.hasChildSeat;
    }

    @Override
    void BoardDriver(Driver driver) {
        if (!super.setDriver(driver, TaxiDriver.class)) {
            System.out.println("Этот водитель не может водить такси!");
        }
    }

    @Override
    void BoardPassenger(Passenger passenger) {
        if (!super.isFull()) {
            this.addPassenger(passenger);
            System.out.println(passenger.getFullName() + " успешно сел!");
        } else {
            System.out.println("Ошибка! " + passenger.getFullName() + " не может сесть! Такси уже полное!");
        }
    }
}
