public interface VehicleBuilder {
    void reset();

    void setDriver(Driver driver);

    void addPassenger(Passenger passenger);

    Vehicle getVehicle();

    int getProfit(int kilometers_passed);
}
