public abstract class Driver {
    private final String surname;
    private final String name;

    protected Driver(String surname, String name) {
        this.surname = surname;
        this.name = name;
    }

    public String getFullName() {
        return this.surname + " " + this.name;
    }
}