public class Main {

    public static String getVehicleStatus(Vehicle vehicle) {
        return "Может отправляться: " + vehicle.canDepart() + ". Заполнено: " + vehicle.isFull();
    }

    public static void demonstrateFullTaxi() {
        TaxiBuilder builder = new TaxiBuilder();

        builder.setDriver(TaxiDriver.getInstance("Водитилев", "Водитель"));
        builder.setChildSeat();
        for (int i = 0; i < 2; i++) {
            builder.addPassenger(new AdultPassenger("Взрослый", "Пассажир " + i));
        }
        builder.addPassenger(new PrivilegePassenger("Льготный", "Пассажир"));
        builder.addPassenger(new ChildPassenger("Молодой", "Пассажир "));
        builder.addPassenger(new AdultPassenger("Взрослый", "Не влезающий Пассажир"));
        System.out.println(getVehicleStatus(builder.getVehicle()));
        System.out.println("Выручка за поездку: " + builder.getProfit(50));
    }

    public static void demonstrateTaxiWithoutChildSeat() {
        TaxiBuilder builder = new TaxiBuilder();
        builder.setDriver(TaxiDriver.getInstance("Водитилев", "Водитель"));
        for (int i = 0; i < 3; i++) {
            builder.addPassenger(new AdultPassenger("Взрослый", "Пассажир " + i));
        }
        try {
            builder.addPassenger(new ChildPassenger("Молодой", "Пассажир "));
        } catch (IllegalStateException exception) {
            System.out.println("Действительно, нельзя посадить молодого пассажира без кресла.");
        }
        builder.setChildSeat();
        builder.addPassenger(new ChildPassenger("Молодой", "Пассажир "));

        System.out.println(getVehicleStatus(builder.getVehicle()));
        System.out.println("Выручка за поездку: " + builder.getProfit(50));
    }

    public static void demonstrateFullBus() {
        BusBuilder builder = new BusBuilder();
        builder.setDriver(BusDriver.getInstance("Водитилев", "Водитель"));
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new AdultPassenger("Взрослый", "Пассажир " + i));
        }
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new PrivilegePassenger("Льготный", "Пассажир " + i));
        }
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new ChildPassenger("Молодой", "Пассажир " + i));
        }
        builder.addPassenger(new AdultPassenger("Взрослый", "Не влезающий Пассажир"));
        System.out.println(getVehicleStatus(builder.getVehicle()));
        System.out.println(builder.getProfit(50));
    }

    public static void demonstrateNotBuiltBus() {
        BusBuilder builder = new BusBuilder();
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new AdultPassenger("Взрослый", "Пассажир " + i));
        }
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new PrivilegePassenger("Льготный", "Пассажир " + i));
        }
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new ChildPassenger("Молодой", "Пассажир " + i));
        }
        try {
            System.out.println(getVehicleStatus(builder.getVehicle()));
        } catch (IllegalStateException exception) {
            System.out.println("Действительно, автобус без водителя не поедет.");
        }
    }

    public static void demonstrateWrongDriverBus() {
        BusBuilder builder = new BusBuilder();
        builder.setDriver(TaxiDriver.getInstance("Водитилев", "Водитель"));
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new AdultPassenger("Взрослый", "Пассажир " + i));
        }
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new PrivilegePassenger("Льготный", "Пассажир " + i));
        }
        for (int i = 0; i < 10; i++) {
            builder.addPassenger(new ChildPassenger("Молодой", "Пассажир " + i));
        }
        try {
            System.out.println(getVehicleStatus(builder.getVehicle()));
        } catch (IllegalStateException exception) {
            System.out.println("Действительно, автобус без водителя не поедет.");
        }
    }


    public static void main(String[] args) {
        demonstrateFullTaxi();
        demonstrateTaxiWithoutChildSeat();
        demonstrateFullBus();
        demonstrateNotBuiltBus();
        demonstrateWrongDriverBus();
    }
}
