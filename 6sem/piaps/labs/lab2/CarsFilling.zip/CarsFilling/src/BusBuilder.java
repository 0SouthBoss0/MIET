public class BusBuilder implements VehicleBuilder {

    private Bus bus;

    public BusBuilder() {
        reset();
    }

    @Override
    public void reset() {
        this.bus = new Bus();
    }

    @Override
    public void setDriver(Driver driver) {
        this.bus.BoardDriver(driver);
    }

    @Override
    public void addPassenger(Passenger passenger) {
        this.bus.BoardPassenger(passenger);
    }

    @Override
    public Vehicle getVehicle() {
        if (this.bus.canDepart()) {
            return this.bus;
        }
        throw new IllegalStateException("Can't depart!");
    }

    @Override
    public int getProfit(int kilometers_passed) {
        int totalSum = 0;
        for (Passenger passenger : this.bus.getPassengers()) {
            totalSum += passenger.getBusCost();
        }
        return totalSum;
    }
}


