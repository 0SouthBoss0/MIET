public class PrivilegePassenger extends Passenger {
    public PrivilegePassenger(String surname, String name) {
        super(surname, name);
    }

    @Override
    public String getPassengerInfo() {
        return "Льготный - пассажир: " + this.getFullName();
    }

    @Override
    public int getTaxiCost(int kilometers_passed) {
        return kilometers_passed * Prices.ADULT_TAXI_KM;
    }

    @Override
    public int getBusCost() {
        return Prices.PRIVILEGE_BUS_TICKET;
    }
}
