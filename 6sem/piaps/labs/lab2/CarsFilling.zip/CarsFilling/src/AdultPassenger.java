public class AdultPassenger extends Passenger {
    public AdultPassenger(String surname, String name) {
        super(surname, name);
    }

    @Override
    public String getPassengerInfo() {
        return "Взрослый - пассажир: " + this.getFullName();
    }

    @Override
    public int getTaxiCost(int kilometers_passed) {
        return kilometers_passed * Prices.ADULT_TAXI_KM;
    }

    @Override
    public int getBusCost() {
        return Prices.ADULT_BUS_TICKET;
    }
}
