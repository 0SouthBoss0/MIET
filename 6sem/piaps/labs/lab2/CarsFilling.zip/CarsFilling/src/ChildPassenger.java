public class ChildPassenger extends Passenger {
    public ChildPassenger(String surname, String name) {
        super(surname, name);
    }

    @Override
    public String getPassengerInfo() {
        return "Ребенок - пассажир: " + this.getFullName();
    }

    @Override
    public int getTaxiCost(int kilometers_passed) {
        return kilometers_passed * Prices.CHILD_TAXI_KM;
    }

    @Override
    public int getBusCost() {
        return Prices.CHILD_BUS_TICKET;
    }


}
