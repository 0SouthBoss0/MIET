import java.util.ArrayList;

public abstract class Vehicle {
    private Driver driver = null;
    private ArrayList<Passenger> passengers = new ArrayList<>();
    private final int capacity;

    public Vehicle(int capacity) {
        this.capacity = capacity;
    }

    abstract void BoardDriver(Driver driver);

    abstract void BoardPassenger(Passenger passenger);

    protected boolean setDriver(Driver driver, Class<?> referenceClass) {
        if (!hasDriver() && referenceClass.isInstance(driver)) {
            this.driver = driver;
            return true;
        }
        return false;
    }

    protected ArrayList<Passenger> getPassengers() {
        return passengers;
    }

    protected boolean addPassenger(Passenger passenger) {
        if (!this.isFull()) {
            this.passengers.add(passenger);
            return true;
        }
        return false;
    }


    boolean isFull() {
        return this.passengers.size() == capacity;
    }

    boolean hasDriver() {
        return this.driver != null;
    }

    boolean hasPassengers() {
        return this.passengers.size() != 0;
    }

    boolean canDepart() {
        return this.hasDriver() && this.hasPassengers();
    }
}
