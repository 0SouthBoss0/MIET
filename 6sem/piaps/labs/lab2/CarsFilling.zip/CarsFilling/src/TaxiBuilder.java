public class TaxiBuilder implements VehicleBuilder {
    private Taxi taxi;

    public TaxiBuilder() {
        reset();
    }

    public void setChildSeat() {
        this.taxi.setChildSeat();
    }


    @Override
    public void reset() {
        this.taxi = new Taxi();
    }

    @Override
    public void setDriver(Driver driver) {
        this.taxi.BoardDriver(driver);
    }

    @Override
    public void addPassenger(Passenger passenger) {
        if (passenger instanceof ChildPassenger && !this.taxi.getHasChildSeat()) {
            throw new IllegalStateException("Need children seat!");
        } else {
            this.taxi.BoardPassenger(passenger);
        }
    }

    @Override
    public Vehicle getVehicle() {
        if (this.taxi.canDepart()) {
            return this.taxi;
        }
        throw new IllegalStateException("Can't depart!");
    }

    @Override
    public int getProfit(int kilometers_passed) {
        int totalSum = 0;
        for (Passenger passenger : this.taxi.getPassengers()) {
            totalSum += passenger.getTaxiCost(kilometers_passed);
        }
        return totalSum;
    }
}
