import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;
import java.util.regex.Pattern;

interface TextExpression {
    String interpret(String context);
}

class MultipleSpacesExpression implements TextExpression {
    @Override
    public String interpret(String context) {
        // заменяем два и более пробелов на один пробел
        return context.replaceAll(" {2,}", " ")
                // удаляем пробелы в начале и конце строки
                .replaceAll("^ +| +$", "");
    }
}

class HyphenToDashExpression implements TextExpression {
    @Override
    public String interpret(String context) {
        return context
                .replaceAll("^-(\\s)", "—$1")          // "- слово" → "— слово"
                .replaceAll("(\\s)-$", "$1—")          // "слово -" → "слово —"
                .replaceAll("^-(\\S)", "— $1")          // "-слово" → "— слово"
                .replaceAll("(\\S)-$", "$1 —")         // "слово-" → "слово —"
                .replaceAll("(\\s)-(\\s)", "$1—$2")     // " - " → " — "
                .replaceAll("(\\s)-(\\S)", "$1— $2")    // " -слово" → " — слово"
                .replaceAll("(\\S)-(\\s)", "$1 —$2")   // "слово- " → "слово — "
                .replaceAll("(\\S)—(\\S)", "$1-$2");   // "слово—слово" → "слово-слово"
    }
}

class QuoteReplacementExpression implements TextExpression {
    @Override
    public String interpret(String context) {
        // заменяем двойные кавычки на кавычки-ёлочки
        // "[^\"]*?" соответствует любому количеству символов, кроме двойной кавычки
        return context.replaceAll("\"([^\"]*?)\"", "«$1»");
    }
}

class TabNormalizationExpression implements TextExpression {
    @Override
    public String interpret(String context) {
        // заменяем один или более символов табуляции на один символ табуляции
        return context.replaceAll("\t+", "\t");
    }
}

class SpaceAroundPunctuationExpression implements TextExpression {
    @Override
    public String interpret(String context) {
        // удаляем пробелы перед закрывающими знаками и после открывающих
        return context.replaceAll("\\s+([].,)?!])", "$1")
                .replaceAll("([\\[(])\\s+", "$1");
    }
}

class MultipleNewlinesExpression implements TextExpression {
    @Override
    public String interpret(String context) {
        // удаляем пробелы перед \n
        return context.replaceAll("[ \\t\\f]+\\n", "\n")
                // удаляем пробелы после \n
                .replaceAll("\\n[ \\t\\f]+", "\n")
                // заменяем 3+ \n на два
                .replaceAll("\n{3,}", "\n\n")
                // удаляем \n в начале и конце
                .replaceAll("^\n+|\n+$", "");
    }
}


class MultiplyPunctuationExpression implements TextExpression {
    // Константы для временных маркеров
    private static final String ELLIPSIS_TEMP = "\uE000";
    private static final String EXCLAM_QUEST_TEMP = "\uE001";
    private static final String TRIPLE_EXCLAM_TEMP = "\uE002";
    private static final String TRIPLE_QUEST_TEMP = "\uE003";

    // Карта для замены специальных последовательностей
    private static final Map<String, String> SPECIAL_SEQUENCES = Map.of(
            "\\.\\.\\.", ELLIPSIS_TEMP,
            "\\?\\!", EXCLAM_QUEST_TEMP,
            "!{3}", TRIPLE_EXCLAM_TEMP,
            "\\?{3}", TRIPLE_QUEST_TEMP
    );

    // Карта для обратной замены временных маркеров
    private static final Map<String, String> TEMP_TO_ORIGINAL = Map.of(
            ELLIPSIS_TEMP, "...",
            EXCLAM_QUEST_TEMP, "?!",
            TRIPLE_EXCLAM_TEMP, "!!!",
            TRIPLE_QUEST_TEMP, "???"
    );

    @Override
    public String interpret(String context) {
        // замена специальных последовательностей на временные маркеры
        context = replaceSpecialSequences(context, true);

        // обработка знаков препинания
        String processed = processPunctuation(context);

        // восстанавление специальных последовательностей
        processed = replaceSpecialSequences(processed, false);

        // нормализация избыточных последовательностей
        return normalizePunctuation(processed);
    }

    private String replaceSpecialSequences(String input, boolean toTemp) {
        Map<String, String> replacementMap = toTemp ? SPECIAL_SEQUENCES : TEMP_TO_ORIGINAL;

        for (Map.Entry<String, String> entry : replacementMap.entrySet()) {
            input = input.replaceAll(entry.getKey(), entry.getValue());
        }
        return input;
    }

    private String processPunctuation(String context) {
        StringBuilder result = new StringBuilder();
        int i = 0;
        int length = context.length();

        while (i < length) {
            char current = context.charAt(i);

            if (isPunctuationOrTempMarker(current)) {
                if (isClosingPunct(current)) {
                    // Для закрывающих знаков добавляем только первый и пропускаем остальные
                    result.append(current);
                    i++;
                    while (i < length && isClosingPunct(context.charAt(i))) {
                        i++;
                    }
                } else {
                    // Для обычных знаков препинания оставляем только первый
                    result.append(current);
                    i++;
                    i = skipRedundantPunctuation(context, i);
                }

                // Добавляем пробел, если он следует за знаком препинания
                if (i < length && context.charAt(i) == ' ') {
                    result.append(' ');
                    i++;
                }
            } else {
                result.append(current);
                i++;
            }
        }

        return result.toString();
    }

    private int skipRedundantPunctuation(String context, int index) {
        int length = context.length();

        while (index < length) {
            char next = context.charAt(index);

            if (isPunctuation(next) && !isClosingPunct(next)) {
                index++;
            } else if (next == ' ') {
                int nextNonSpace = findNextNonSpace(context, index + 1);
                if (nextNonSpace < length && isPunctuation(context.charAt(nextNonSpace))
                        && !isClosingPunct(context.charAt(nextNonSpace))) {
                    index = nextNonSpace;
                } else {
                    break;
                }
            } else {
                break;
            }
        }

        return index;
    }

    // Находит следующий не-пробельный символ
    private int findNextNonSpace(String str, int start) {
        while (start < str.length() && str.charAt(start) == ' ') {
            start++;
        }
        return start;
    }

    // Нормализует избыточные последовательности знаков препинания
    private String normalizePunctuation(String input) {
        return input.replaceAll("\\.{4,}", ".")
                .replaceAll("!{4,}", "!")
                .replaceAll("\\?{4,}", "?")
                .replaceAll("(\\?!){2,}", "?!");
    }

    // Проверяет, является ли символ закрывающим знаком препинания
    private boolean isClosingPunct(char c) {
        return c == ')' || c == ']' || c == '}' || c == '»' || c == '”' || c == '’';
    }

    // Проверяет, является ли символ знаком препинания
    private boolean isPunctuation(char c) {
        return Pattern.matches("\\p{Punct}", String.valueOf(c));
    }

    // Проверяет, является ли символ знаком препинания или временным маркером
    private boolean isPunctuationOrTempMarker(char c) {
        return isPunctuation(c) ||
                c == ELLIPSIS_TEMP.charAt(0) ||
                c == EXCLAM_QUEST_TEMP.charAt(0) ||
                c == TRIPLE_EXCLAM_TEMP.charAt(0) ||
                c == TRIPLE_QUEST_TEMP.charAt(0);
    }
}

class CapitalizeSentencesExpression implements TextExpression {
    @Override
    public String interpret(String context) {
        StringBuilder result = new StringBuilder(context);
        for (int i = 0; i < result.length(); i++) {
            if (Character.isLetter(result.charAt(i))) {
                result.setCharAt(i, Character.toUpperCase(result.charAt(i)));
                break;
            }
        }
        String capitalizedText = result.toString();

        // Теперь обрабатываем остальные предложения
        String[] parts = capitalizedText.split("(?<=[.!?…])(?=\\s+[a-zа-я])");

        result = new StringBuilder();

        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }

            // Находим первую букву после разделителя и делаем её заглавной
            boolean found = false;
            for (int i = 0; i < part.length(); i++) {
                char c = part.charAt(i);
                if (Character.isLetter(c)) {
                    // Заменяем первую букву на заглавную, сохраняя пробелы
                    String capitalized = part.substring(0, i)
                            + Character.toUpperCase(c)
                            + part.substring(i + 1);
                    result.append(capitalized);
                    found = true;
                    break;
                }
            }
            if (!found) {
                // Если не нашли букв, добавляем как есть
                result.append(part);
            }
        }

        return result.toString();
    }
}

class TextCorrectionExpression implements TextExpression {
    private final TextExpression[] expressions;

    public TextCorrectionExpression() {
        this.expressions = new TextExpression[]{
                new MultipleSpacesExpression(),
                new TabNormalizationExpression(),
                new SpaceAroundPunctuationExpression(),
                new MultipleNewlinesExpression(),
                new HyphenToDashExpression(),
                new QuoteReplacementExpression(),
                new MultiplyPunctuationExpression(),
                new CapitalizeSentencesExpression()
        };
    }

    @Override
    public String interpret(String context) {
        String result = context;
        for (TextExpression expression : expressions) {
            result = expression.interpret(result);
        }
        return result;
    }
}

public class TextEditor extends JFrame {
    protected final JTextArea textArea;
    protected final TextExpression correctionExpression;

    public TextEditor() {
        setTitle("Редактор текста с исправлением");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        correctionExpression = new TextCorrectionExpression();

        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);

        JButton checkButton = new JButton("Проверить");
        JButton correctButton = new JButton("Исправить");

        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkText();
            }
        });

        correctButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                correctText();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(checkButton);
        buttonPanel.add(correctButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    protected void checkText() {
        String text = textArea.getText();
        String corrected = correctionExpression.interpret(text);

        if (text.equals(corrected)) {
            JOptionPane.showMessageDialog(this, "Ошибок не найдено!", "Проверка завершена", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Ошибки найдены. Нажмите \"Исправить\" для их устранения!",
                    "Проверка завершена", JOptionPane.WARNING_MESSAGE);
        }
    }

    protected void correctText() {
        String text = textArea.getText();
        String corrected = correctionExpression.interpret(text);
        textArea.setText(corrected);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TextEditor().setVisible(true);
            }
        });
    }
}