import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TextExpressionTests {

    @Test
    void testMultipleSpacesExpression() {
        TextExpression expression = new MultipleSpacesExpression();

        assertEquals("один пробел", expression.interpret("один  пробел"));
        assertEquals("начало конец", expression.interpret("начало   конец"));
        assertEquals("", expression.interpret("   "));
        assertEquals("текст", expression.interpret("  текст  "));
        assertEquals("a b c d", expression.interpret("a    b   c    d"));
        assertEquals("без изменений", expression.interpret("без изменений"));
        assertEquals("много пробелов между словами", expression.interpret("много   пробелов   между   словами"));
        assertEquals("лишние пробелы в начале и конце", expression.interpret("  лишние  пробелы  в  начале  и  конце  "));
        assertEquals("no changes", expression.interpret("no changes"));
        assertEquals("1 2 3 4", expression.interpret("1  2   3    4"));
    }

    @Test
    void testHyphenToDashExpression() {
        TextExpression expression = new HyphenToDashExpression();

        // Основные случаи
        assertEquals("слово — слово", expression.interpret("слово - слово"));
        assertEquals("Фраза — с — тире", expression.interpret("Фраза - с - тире"));
        assertEquals("— слово", expression.interpret("- слово"));
        assertEquals("слово —", expression.interpret("слово -"));
        assertEquals("— слово", expression.interpret("-слово"));
        assertEquals("слово —", expression.interpret("слово-"));
        assertEquals("слово — слово", expression.interpret("слово -слово"));
        assertEquals("слово — слово", expression.interpret("слово- слово"));

        // Случаи без изменений
        assertEquals("слово-слово", expression.interpret("слово-слово"));
        assertEquals("123-45", expression.interpret("123-45"));
        assertEquals("e-mail", expression.interpret("e-mail"));
        assertEquals("пол-литра", expression.interpret("пол-литра"));

        // Комплексные случаи
        assertEquals("Ввод — вывод", expression.interpret("Ввод - вывод"));
        assertEquals("— Да — нет —", expression.interpret("- Да - нет -"));
        assertEquals("Глава 1 — Введение", expression.interpret("Глава 1 - Введение"));
        assertEquals("10-20 лет", expression.interpret("10-20 лет"));
        assertEquals("10-20 лет", expression.interpret("10—20 лет"));
    }

    @Test
    void testQuoteReplacementExpression() {
        TextExpression expression = new QuoteReplacementExpression();

        assertEquals("«кавычки»", expression.interpret("\"кавычки\""));
        assertEquals("«внутри» текст", expression.interpret("\"внутри\" текст"));
        assertEquals("без кавычек", expression.interpret("без кавычек"));
        assertEquals("«одинарные» и «двойные»", expression.interpret("\"одинарные\" и \"двойные\""));
        assertEquals("«начало» и «конец»", expression.interpret("\"начало\" и \"конец\""));
        assertEquals("«123»", expression.interpret("\"123\""));
        assertEquals("«»", expression.interpret("\"\""));
        assertEquals("текст «в кавычках» текст", expression.interpret("текст \"в кавычках\" текст"));
    }

    @Test
    void testTabNormalizationExpression() {
        TextExpression expression = new TabNormalizationExpression();

        assertEquals("\tнормально", expression.interpret("\t\tнормально"));
        assertEquals("начало\tконец", expression.interpret("начало\t\t\tконец"));
        assertEquals("\t", expression.interpret("\t\t\t"));
        assertEquals("текст\t", expression.interpret("текст\t\t"));
        assertEquals("\tтекст", expression.interpret("\t\tтекст"));
        assertEquals("без\tизменений", expression.interpret("без\tизменений"));
        assertEquals("много\tтабов\tмежду\tсловами", expression.interpret("много\t\tтабов\t\t\tмежду\t\t\t\tсловами"));
        assertEquals("\tначало\tсередина\tконец\t", expression.interpret("\t\tначало\t\t\tсередина\t\t\t\tконец\t\t"));
        assertEquals("1\t2\t3\t4", expression.interpret("1\t\t2\t\t\t3\t\t\t\t4"));
    }

    @Test
    void testSpaceAroundPunctuationExpression() {
        TextExpression expression = new SpaceAroundPunctuationExpression();

        assertEquals("(правильно)", expression.interpret("( правильно )"));
        assertEquals("Точка. Запятая, текст", expression.interpret("Точка . Запятая , текст"));
        assertEquals("a, b, c", expression.interpret("a , b , c"));
        assertEquals("(a (b) c)", expression.interpret("( a ( b ) c )"));
        assertEquals("x. y, z", expression.interpret("x . y , z"));
        assertEquals("No [space] here", expression.interpret("No [ space ] here"));
        assertEquals("Test (a, b, c)", expression.interpret("Test ( a , b , c )"));
        assertEquals("Много [скобок] (в (text))", expression.interpret("Много [ скобок ] ( в ( text ) )"));
        assertEquals("1. 2. 3.", expression.interpret("1 . 2 . 3 ."));
    }

    @Test
    void testMultipleNewlinesExpression() {
        TextExpression expression = new MultipleNewlinesExpression();

        assertEquals("два\n\nпереноса", expression.interpret("два\n\n\nпереноса"));
        assertEquals("начало", expression.interpret("\n\n\n\nначало"));
        assertEquals("", expression.interpret("\n\n\n"));
        assertEquals("текст", expression.interpret("текст\n\n\n"));
        assertEquals("текст", expression.interpret("\n\n\nтекст"));
        assertEquals("один\nдва", expression.interpret("один\nдва"));
        assertEquals("начало\n\nсередина\n\nконец", expression.interpret("\n\nначало\n\n\nсередина\n\n\n\nконец\n\n"));
        assertEquals("параграф\n\nдругой", expression.interpret("параграф\n\n\n\nдругой"));
        assertEquals("много\n\nпереносов\n\nстрок", expression.interpret("много\n\n\nпереносов\n\n\n\nстрок"));
        assertEquals("1\n2\n3", expression.interpret("1\n2\n3"));
        assertEquals("финал", expression.interpret("\n\n\nфинал\n\n\n"));
    }

    @Test
    void testMultiplePunctiationExpression() {
        TextExpression expression = new MultiplyPunctuationExpression();

        assertEquals("слово. b", expression.interpret("слово. b"));
        assertEquals("слово; b", expression.interpret("слово;., b"));
        assertEquals("слово; b", expression.interpret("слово; . , b"));
        assertEquals("a, b, c", expression.interpret("a,,,, b, c"));
        assertEquals("a... b", expression.interpret("a... b"));
        assertEquals("a... b", expression.interpret("a.... b"));
        assertEquals("a, b, c", expression.interpret("a,,,, b, c"));
        assertEquals("Wow! Really?", expression.interpret("Wow!! Really??"));
        assertEquals("Test...", expression.interpret("Test....."));
        assertEquals("End.", expression.interpret("End..!!.."));
        assertEquals("What?!", expression.interpret("What?!?!"));
        assertEquals("Special!!!", expression.interpret("Special!!!"));
        assertEquals("Question???", expression.interpret("Question????"));
        assertEquals("Comma, period...", expression.interpret("Comma,,, period...."));
        assertEquals("Comma, period)", expression.interpret("Comma,,, period))"));
        assertEquals("(Comma, period)", expression.interpret("((((Comma,,, period))"));
    }

    @Test
    void testCapitalizeSentencesExpression() {
        TextExpression expression = new CapitalizeSentencesExpression();

        assertEquals("Первое предложение. Второе предложение.",
                expression.interpret("Первое предложение. второе предложение."));
        assertEquals("Что это? Это тест!",
                expression.interpret("что это? это тест!"));
        assertEquals("Внимание!!! Важное сообщение.",
                expression.interpret("внимание!!! важное сообщение."));
        assertEquals("Зачем??? Потому что.",
                expression.interpret("зачем??? потому что."));
        assertEquals("Серьёзно?! Да, серьёзно.",
                expression.interpret("серьёзно?! да, серьёзно."));
        assertEquals("\tПример. \tС табуляцией.",
                expression.interpret("\tпример. \tс табуляцией."));
        assertEquals("Многоточие... Продолжение.",
                expression.interpret("многоточие... продолжение."));
        assertEquals("Первая строка.\nВторая строка.",
                expression.interpret("первая строка.\nвторая строка."));
        assertEquals("Комбинация!?\nНовая строка.",
                expression.interpret("комбинация!?\nновая строка."));
        assertEquals("Уже правильно. Без изменений.",
                expression.interpret("Уже правильно. Без изменений."));
        // Добавляем тест с несколькими пробелами
        assertEquals("Тест.   С пробелами.",
                expression.interpret("тест.   с пробелами."));
    }

    @Test
    void testTextCorrectionExpression() {
        TextExpression expression = new TextCorrectionExpression();

        // Простые случаи
        String input1 = "Это  тест  -  \"кавычки\"  \t\tи  пробелы.\n\n\n";
        String expected1 = "Это тест — «кавычки» \tи пробелы.";
        assertEquals(expected1, expression.interpret(input1));

        String input2 = "  Много  \t\tошибок  (  здесь  )  -  \"исправить\"  \n\n\nвсе";
        String expected2 = "Много \tошибок (здесь) — «исправить»\n\nвсе";
        assertEquals(expected2, expression.interpret(input2));

        // Сложные случаи
        String input3 = "  \t\tДефис-в-слове  -  \"кавычки\"  .  \n\n\n\nКонец";
        String expected3 = "\tДефис-в-слове — «кавычки».\n\nКонец";
        assertEquals(expected3, expression.interpret(input3));

        String input4 = "  (  \"Текст [в] скобках\"  )  -  \"цитата\"  \n\n\n  Конец  ";
        String expected4 = "(«Текст [в] скобках») — «цитата»\n\nКонец";
        assertEquals(expected4, expression.interpret(input4));

        // Комплексные документы
        String input5 = "  Документ  \n\n  \"Цитата\"  -  пример  (  текст  )  .  \t\t  \n\n\n  Конец  ";
        String expected5 = "Документ\n\n«Цитата» — пример (текст).\n\nКонец";
        assertEquals(expected5, expression.interpret(input5));

        String input6 = "  \"тест\"  -  пример  \t\t  \n\n\n";
        String expected6 = "«Тест» — пример";
        assertEquals(expected6, expression.interpret(input6));

        // Дополнительные тесты
        String input7 = "Глава 1 - Введение\n\n  \"Цель\"  -  изучить  (  материал  )  .  \t\t  \n\n\n  Конец главы  ";
        String expected7 = "Глава 1 — Введение\n\n«Цель» — изучить (материал).\n\nКонец главы";
        assertEquals(expected7, expression.interpret(input7));

        String input8 = "Пункт 1 - пункт 2 - пункт 3\n\n\"Важно\":  запомнить  !  \t\t  \n\n\n";
        String expected8 = "Пункт 1 — пункт 2 — пункт 3\n\n«Важно»: запомнить!";
        assertEquals(expected8, expression.interpret(input8));

        String input9 = "Список:\n\n1.  Первый  (  важный  )  \n2.  Второй  \n3.  Третий  !!!  \n\n\n";
        String expected9 = "Список:\n\n1. Первый (важный)\n2. Второй\n3. Третий!!!";
        assertEquals(expected9, expression.interpret(input9));
    }
}