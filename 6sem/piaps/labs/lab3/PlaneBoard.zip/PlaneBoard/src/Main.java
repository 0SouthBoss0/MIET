public class Main {
    public static void demonstrateNormalBoarding() {
        Aircraft aircraft = new Aircraft(1000, 2, 3, 2, 5, 30);
        for (int i = 0; i < 2; i++) {
            aircraft.add(new Pilot("Пилот " + i));
        }
        for (int i = 0; i < 3; i++) {
            aircraft.add(new Steward("Стюард " + i));
        }

        FirstClass firstClass = new FirstClass(aircraft.getMaxFirstClass());
        for (int i = 0; i < 2; i++) {
            firstClass.add(new Passenger("Пассажир " + i, 10));
        }
        aircraft.add(firstClass);

        BusinessClass businessClass = new BusinessClass(aircraft.getMaxBusinessClass());
        for (int i = 0; i < 5; i++) {
            businessClass.add(new Passenger("Пассажир " + i, 10));
        }
        aircraft.add(businessClass);

        EconomyClass economyClass = new EconomyClass(aircraft.getMaxEconomyClass());
        for (int i = 0; i < 30; i++) {
            economyClass.add(new Passenger("Пассажир " + i, 10));
        }
        aircraft.add(economyClass);

        aircraft.prepareForDeparture();
    }

    public static void demonstrateOverloadBoarding() {
        Aircraft aircraft = new Aircraft(1000, 2, 3, 2, 5, 30);
        for (int i = 0; i < 2; i++) {
            aircraft.add(new Pilot("Пилот " + i));
        }
        for (int i = 0; i < 3; i++) {
            aircraft.add(new Steward("Стюард " + i));
        }

        FirstClass firstClass = new FirstClass(aircraft.getMaxFirstClass());
        for (int i = 0; i < 2; i++) {
            firstClass.add(new Passenger("Пассажир " + i, 10));
        }
        aircraft.add(firstClass);

        BusinessClass businessClass = new BusinessClass(aircraft.getMaxBusinessClass());
        for (int i = 0; i < 5; i++) {
            businessClass.add(new Passenger("Пассажир " + i, 10));
        }
        aircraft.add(businessClass);

        EconomyClass economyClass = new EconomyClass(aircraft.getMaxEconomyClass());
        for (int i = 0; i < 30; i++) {
            economyClass.add(new Passenger("Пассажир " + i, 50));
        }
        aircraft.add(economyClass);

        aircraft.prepareForDeparture();
    }

    public static void demonstrateExtremeOverloadBoarding() {
        Aircraft aircraft = new Aircraft(10, 2, 3, 2, 5, 30);
        for (int i = 0; i < 2; i++) {
            aircraft.add(new Pilot("Пилот " + i));
        }
        for (int i = 0; i < 3; i++) {
            aircraft.add(new Steward("Стюард " + i));
        }

        FirstClass firstClass = new FirstClass(aircraft.getMaxFirstClass());
        for (int i = 0; i < 2; i++) {
            firstClass.add(new Passenger("Пассажир " + i, 50));
        }
        aircraft.add(firstClass);

        BusinessClass businessClass = new BusinessClass(aircraft.getMaxBusinessClass());
        for (int i = 0; i < 5; i++) {
            businessClass.add(new Passenger("Пассажир " + i, 50));
        }
        aircraft.add(businessClass);

        EconomyClass economyClass = new EconomyClass(aircraft.getMaxEconomyClass());
        for (int i = 0; i < 30; i++) {
            economyClass.add(new Passenger("Пассажир " + i, 50));
        }
        aircraft.add(economyClass);
        try {
            aircraft.prepareForDeparture();
        } catch (Exception e) {
            System.out.println("Действительно, если не выкинуть багаж из первого и бизнес класса - взлететь нельзя!");
        }
    }

    public static void demonstrateFirstClassOverFlow() {
        Aircraft aircraft = new Aircraft(10, 2, 3, 2, 5, 30);
        for (int i = 0; i < 2; i++) {
            aircraft.add(new Pilot("Пилот " + i));
        }
        for (int i = 0; i < 3; i++) {
            aircraft.add(new Steward("Стюард " + i));
        }

        FirstClass firstClass = new FirstClass(aircraft.getMaxFirstClass());
        for (int i = 0; i < 3; i++) {
            try {
                firstClass.add(new Passenger("Пассажир " + i, 5));
            } catch (Exception exception) {
                System.out.println("Действительно, первый класс переполнен!");
            }
        }
        aircraft.add(firstClass);
        aircraft.prepareForDeparture();


    }

    public static void main(String[] args) {
        demonstrateNormalBoarding();
        demonstrateOverloadBoarding();
        demonstrateExtremeOverloadBoarding();
        demonstrateFirstClassOverFlow();
    }
}
