public enum ServiceClass {
    FIRST_CLASS,
    BUSINESS_CLASS,
    ECONOMY_CLASS
}
