public class Steward extends AircraftComponent {
    private final String name;

    public Steward(String name) {
        this.name = name;
    }

    @Override
    void add(AircraftComponent component) {
        throw new UnsupportedOperationException("Cannot add to a steward");
    }

    @Override
    int getBaggageWeight() {
        return 0;
    }

    @Override
    int calculateBaggageFee() {
        return 0;
    }

    @Override
    void prepareForDeparture() {
        System.out.println("Steward " + name + " is ready for departure.");
    }
}
