import java.util.ArrayList;

public class EconomyClass extends AircraftComponent{
    public ArrayList<AircraftComponent> getPassengers() {
        return passengers;
    }

    private ArrayList<AircraftComponent> passengers;
    private final int limit;

    public EconomyClass(int limit) {
        this.passengers = new ArrayList<>();
        this.limit = limit;
    }

    @Override
    void add(AircraftComponent component) {
        if (this.passengers.size() == limit) {
            throw new UnsupportedOperationException("Economy class already full!");
        }
        if (component instanceof Passenger) {
            ((Passenger) component).setServiceClass(ServiceClass.ECONOMY_CLASS);
            passengers.add(component);
        } else {
            throw new UnsupportedOperationException("Cannot add not passenger to a economy class!");
        }

    }

    @Override
    int getBaggageWeight() {
        int s = 0;
        for (AircraftComponent component : this.passengers) {
            s += component.getBaggageWeight();
        }
        return s;
    }

    @Override
    int calculateBaggageFee() {
        int s = 0;
        for (AircraftComponent component : this.passengers) {
            s += component.calculateBaggageFee();
        }
        return s;
    }

    @Override
    void prepareForDeparture() {
        for (AircraftComponent component : this.passengers) {
            component.prepareForDeparture();
        }
        System.out.println("Economy class with " + this.passengers.size() + " passengers is ready for departure with "
                + this.getBaggageWeight() + " kg baggage. Tax: " + this.calculateBaggageFee());

    }
}
