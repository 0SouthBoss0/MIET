public class Passenger extends AircraftComponent {
    private final String name;
    private ServiceClass serviceClass = null;

    private int baggageWeight;

    public Passenger(String name, int baggageWeight) {
        if (baggageWeight < 5 || baggageWeight > 60) {
            throw new IllegalArgumentException("Baggage weight must be between 5 and 60 kg.");
        }
        this.name = name;
        this.baggageWeight = baggageWeight;
    }

    public void setBaggageWeight(int baggageWeight) {
        this.baggageWeight = baggageWeight;
    }

    public void setServiceClass(ServiceClass serviceClass) {
        this.serviceClass = serviceClass;
    }

    public void takeawayBaggage(){
        this.setBaggageWeight(0);
        System.out.println("Baggage for passenger " + name + " was taken away!");
    }

    @Override
    void add(AircraftComponent component) {
        throw new UnsupportedOperationException("Cannot add to a passenger");
    }

    @Override
    int getBaggageWeight() {
        return this.baggageWeight;
    }

    @Override
    int calculateBaggageFee() {
        if (this.serviceClass != null) {
            if (this.serviceClass == ServiceClass.BUSINESS_CLASS && this.baggageWeight > Taxes.BUSINESS_FREE_BAGGAGE_KG) {
                return (this.baggageWeight - Taxes.BUSINESS_FREE_BAGGAGE_KG) * Taxes.EXTRA_BAGGAGE_RUB_PER_KG;
            }
            if (this.serviceClass == ServiceClass.ECONOMY_CLASS && this.baggageWeight > Taxes.ECONOMY_FREE_BAGGAGE_KG) {
                return (this.baggageWeight - Taxes.ECONOMY_FREE_BAGGAGE_KG) * Taxes.EXTRA_BAGGAGE_RUB_PER_KG;
            }
            return 0;
        }
        throw new UnsupportedOperationException("You need to board passenger before calculating his baggage fee!");
    }

    @Override
    void prepareForDeparture() {
        System.out.println("Passenger " + name + " is ready for departure with " + this.getBaggageWeight() + " kg baggage. Tax: " + calculateBaggageFee());
    }
}
