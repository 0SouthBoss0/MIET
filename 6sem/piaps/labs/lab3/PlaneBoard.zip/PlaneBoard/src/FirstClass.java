import java.util.ArrayList;

public class FirstClass extends AircraftComponent {
    private ArrayList<AircraftComponent> passengers;
    private final int limit;

    public FirstClass(int limit) {
        this.passengers = new ArrayList<>();
        this.limit = limit;
    }

    @Override
    void add(AircraftComponent component) {
        if (this.passengers.size() == limit) {
            throw new UnsupportedOperationException("First class already full!");
        }
        if (component instanceof Passenger) {
            ((Passenger) component).setServiceClass(ServiceClass.FIRST_CLASS);
            passengers.add(component);
        } else {
            throw new UnsupportedOperationException("Cannot add not passenger to a first class!");
        }

    }

    @Override
    int getBaggageWeight() {
        int s = 0;
        for (AircraftComponent component : this.passengers) {
            s += component.getBaggageWeight();
        }
        return s;
    }

    @Override
    int calculateBaggageFee() {
        int s = 0;
        for (AircraftComponent component : this.passengers) {
            s += component.calculateBaggageFee();
        }
        return s;
    }

    @Override
    void prepareForDeparture() {
        for (AircraftComponent component : this.passengers) {
            component.prepareForDeparture();
        }
        System.out.println("First class with " + this.passengers.size() + " passengers is ready for departure with "
                + this.getBaggageWeight() + " kg baggage. Tax: " + this.calculateBaggageFee());
    }
}
