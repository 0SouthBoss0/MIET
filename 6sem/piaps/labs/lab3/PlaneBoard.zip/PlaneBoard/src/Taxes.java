public class Taxes {
    public static final int BUSINESS_FREE_BAGGAGE_KG = 30;
    public static final int ECONOMY_FREE_BAGGAGE_KG = 20;
    public static final int EXTRA_BAGGAGE_RUB_PER_KG = 20;
}
