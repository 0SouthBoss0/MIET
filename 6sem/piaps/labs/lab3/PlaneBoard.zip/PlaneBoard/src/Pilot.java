public class Pilot extends AircraftComponent {
    private final String name;

    public Pilot(String name) {
        this.name = name;
    }

    @Override
    void add(AircraftComponent component) {
        throw new UnsupportedOperationException("Cannot add to a pilot");
    }

    @Override
    int getBaggageWeight() {
        return 0;
    }

    @Override
    int calculateBaggageFee() {
        return 0;
    }

    @Override
    void prepareForDeparture() {
        System.out.println("Pilot " + name + " is ready for departure.");
    }
}
