import java.util.ArrayList;
import java.util.Collections;

public class Aircraft extends AircraftComponent {
    private ArrayList<AircraftComponent> components;
    private final int maxBaggageWeight;
    private final int maxPilots;
    private final int maxStewards;
    private final int maxFirstClass;
    private final int maxBusinessClass;
    private final int maxEconomyClass;


    public Aircraft(int maxBaggageWeight, int maxPilots, int maxStewards, int maxFirstClass, int maxBusinessClass, int maxEconomyClass) {
        this.components = new ArrayList<>();
        this.maxBaggageWeight = maxBaggageWeight;
        this.maxPilots = maxPilots;
        this.maxStewards = maxStewards;
        this.maxFirstClass = maxFirstClass;
        this.maxBusinessClass = maxBusinessClass;
        this.maxEconomyClass = maxEconomyClass;
    }

    @Override
    void add(AircraftComponent component) {
        if (component instanceof Pilot && getPilotCount() >= this.maxPilots) {
            throw new UnsupportedOperationException("Cannot add more pilots. Maximum capacity reached.");
        }
        if (component instanceof Steward && getStewardCount() >= this.maxStewards) {
            throw new UnsupportedOperationException("Cannot add more stewardesses. Maximum capacity reached.");
        }
        components.add(component);
    }

    @Override
    int getBaggageWeight() {
        int s = 0;
        for (AircraftComponent component : this.components) {
            s += component.getBaggageWeight();
        }
        return s;
    }

    @Override
    int calculateBaggageFee() {
        int s = 0;
        for (AircraftComponent component : this.components) {
            s += component.calculateBaggageFee();
        }
        return s;
    }

    @Override
    void prepareForDeparture() {
        if (this.getBaggageWeight() > maxBaggageWeight) {
            int excessWeight = this.getBaggageWeight() - maxBaggageWeight;
            System.out.println("Baggage weight exceeds maximum by " + excessWeight + " kg.");
            if (removeExcessBaggage(excessWeight)) {
                System.out.println("Baggage weight fixed.");
            } else {
                throw new UnsupportedOperationException("Cannot fly!");
            }
        } else {
            System.out.println("Baggage weight is within limits.");
        }
        System.out.println("Total baggage fee: $" + calculateBaggageFee());

        for (AircraftComponent component : components) {
            component.prepareForDeparture();
        }

    }

    private boolean removeExcessBaggage(int excessWeight) {
        for (AircraftComponent component : components) {
            if (component instanceof EconomyClass) {
                ArrayList<AircraftComponent> passengers = ((EconomyClass) component).getPassengers();
                Collections.reverse(passengers);
                int exceed = 0;
                for (AircraftComponent passenger : passengers) {
                    if (exceed < excessWeight) {
                        exceed += passenger.getBaggageWeight();
                        ((Passenger) passenger).takeawayBaggage();
                    }
                }
                Collections.reverse(passengers);
                return exceed >= excessWeight;
            }
        }
        throw new UnsupportedOperationException("No economy class to remove baggage!");
    }

    private int getPilotCount() {
        int count = 0;
        for (AircraftComponent component : this.components) {
            if (component instanceof Pilot) {
                count++;
            }
        }
        return count;
    }

    private int getStewardCount() {
        int count = 0;
        for (AircraftComponent component : this.components) {
            if (component instanceof Steward) {
                count++;
            }
        }
        return count;
    }

    public int getMaxFirstClass() {
        return maxFirstClass;
    }

    public int getMaxBusinessClass() {
        return maxBusinessClass;
    }

    public int getMaxEconomyClass() {
        return maxEconomyClass;
    }
}
