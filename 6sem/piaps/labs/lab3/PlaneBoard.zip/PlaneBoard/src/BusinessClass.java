import java.util.ArrayList;

public class BusinessClass extends AircraftComponent {
    private ArrayList<AircraftComponent> passengers;
    private final int limit;

    public BusinessClass(int limit) {
        this.passengers = new ArrayList<>();
        this.limit = limit;
    }

    @Override
    void add(AircraftComponent component) {
        if (this.passengers.size() == limit) {
            throw new UnsupportedOperationException("Business class already full!");
        }
        if (component instanceof Passenger) {
            ((Passenger) component).setServiceClass(ServiceClass.BUSINESS_CLASS);
            passengers.add(component);
        } else {
            throw new UnsupportedOperationException("Cannot add not passenger to a business class!");
        }

    }

    @Override
    int getBaggageWeight() {
        int s = 0;
        for (AircraftComponent component : this.passengers) {
            s += component.getBaggageWeight();
        }
        return s;
    }

    @Override
    int calculateBaggageFee() {
        int s = 0;
        for (AircraftComponent component : this.passengers) {
            s += component.calculateBaggageFee();
        }
        return s;
    }

    @Override
    void prepareForDeparture() {
        for (AircraftComponent component : this.passengers) {
            component.prepareForDeparture();
        }
        System.out.println("Business class with " + this.passengers.size() + " passengers is ready for departure with "
                + this.getBaggageWeight() + " kg baggage. Tax: " + this.calculateBaggageFee());

    }
}
