public abstract class AircraftComponent {
    abstract void add(AircraftComponent component);

    abstract int getBaggageWeight();

    abstract int calculateBaggageFee();

    abstract void prepareForDeparture();
}
