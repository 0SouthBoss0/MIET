public class TaxiFactory implements TransportAbstractFactory {

    @Override
    public Driver createDriver(String surname, String name) {
        return TaxiDriver.getInstance(surname, name);
    }

    @Override
    public Passenger createPassenger(String surname, String name) {
        return new Passenger(surname, name);
    }

    @Override
    public Vehicle createVehicle() {
        return new Taxi();
    }
}
