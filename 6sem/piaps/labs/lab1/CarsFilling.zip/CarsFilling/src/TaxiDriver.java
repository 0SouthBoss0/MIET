public class TaxiDriver extends Driver {

    private static volatile TaxiDriver instance;

    private TaxiDriver(String surname, String name) {
        super(surname, name);
    }

    public static TaxiDriver getInstance(String surname, String name) {
        if (instance == null) {
            synchronized (TaxiDriver.class) {
                if (instance == null) {
                    instance = new TaxiDriver(surname, name);
                }
            }
        }
        return instance;
    }

    @Override
    public String getFullName() {
        return "Водитель такси: " + super.getFullName();
    }
}
