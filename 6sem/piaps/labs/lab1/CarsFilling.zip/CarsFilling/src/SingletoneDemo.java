public class SingletoneDemo {
    public static void demonstrate() {
        TaxiDriver taxiDriver1 = TaxiDriver.getInstance("Иванов", "Иван");
        System.out.println("<taxiDriver1>: " + taxiDriver1.getFullName());
        TaxiDriver taxiDriver2 = TaxiDriver.getInstance("Петров", "Пётр");
        System.out.println("<taxiDriver2>: " + taxiDriver2.getFullName());
        System.out.println("<taxiDriver1 equals taxiDriver2>: " + taxiDriver1.equals(taxiDriver2));

        BusDriver busDriver1 = BusDriver.getInstance("Сидоров", "Сидор");
        System.out.println("<busDriver1>: " + busDriver1.getFullName());
        BusDriver busDriver2 = BusDriver.getInstance("Васильев", "Василий");
        System.out.println("<busDriver2>: " + busDriver2.getFullName());
        System.out.println("<busDriver1 equals busDriver2>: " + busDriver1.equals(busDriver2) + "\n");
    }
}
