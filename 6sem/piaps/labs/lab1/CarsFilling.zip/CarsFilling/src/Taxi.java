public class Taxi extends Vehicle {
    public Taxi() {
        super(4);
    }

    @Override
    void BoardDriver(Driver driver) {
        if (driver instanceof TaxiDriver) {
            super.setDriver(driver);
            System.out.println(driver.getFullName() + " успешно занял водительское место!");
        } else {
            System.out.println("Ошибка! " + driver.getFullName() + " не может водить такси!");
        }
    }

    @Override
    void BoardPassenger(Passenger passenger) {
        if (!super.isFull()) {
            this.addPassenger(passenger);
            System.out.println(passenger.getFullName() + " успешно сел!");
        } else {
            System.out.println("Ошибка! " + passenger.getFullName() + " не может сесть! Такси уже полное!");
        }
    }
}
