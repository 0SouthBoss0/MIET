public interface TransportAbstractFactory {
    Driver createDriver(String surname, String name);

    Passenger createPassenger(String surname, String name);

    Vehicle createVehicle();

}