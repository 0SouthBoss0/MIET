public class Bus extends Vehicle {
    public Bus() {
        super(30);
    }


    @Override
    void BoardDriver(Driver driver) {
        if (driver instanceof BusDriver) {
            super.setDriver(driver);
            System.out.println(driver.getFullName() + " успешно занял водительское место!");
        } else {
            System.out.println("Ошибка! " + driver.getFullName() + " не может водить автобус!");
        }
    }

    @Override
    void BoardPassenger(Passenger passenger) {
        if (!super.isFull()) {
            this.addPassenger(passenger);
            System.out.println(passenger.getFullName() + " успешно сел!");
        } else {
            System.out.println("Ошибка! " + passenger.getFullName() + " не может сесть! Автобус уже полон!");
        }
    }
}
