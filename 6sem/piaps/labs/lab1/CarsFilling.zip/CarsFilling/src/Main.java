public class Main {
    public static void main(String[] args) {
        SingletoneDemo.demonstrate();
        BoardingDemo.demonstrateTaxi();
        BoardingDemo.demonstrateBus();
    }
}
