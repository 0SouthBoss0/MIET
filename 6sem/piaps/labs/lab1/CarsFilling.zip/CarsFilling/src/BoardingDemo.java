import java.util.ArrayList;

public class BoardingDemo {

    private static void getVehicleStatus(Vehicle vehicle) {
        System.out.println("Готовность транспорта: " + vehicle.hasDriver() + " Транспорт заполнен: " + vehicle.isFull());
    }


    private static void processBoard(TransportAbstractFactory factory, int passengersToBoard) {
        ArrayList<Passenger> passengers = new ArrayList<>();
        Driver driver = factory.createDriver("Иванов", "Иван");
        Vehicle vehicle = factory.createVehicle();
        for (int i = 0; i < passengersToBoard; i++) {
            Passenger passenger = factory.createPassenger("Пассажиров", "Пассажир_" + (i + 1));
            passengers.add(passenger);
        }

        getVehicleStatus(vehicle);
        vehicle.BoardDriver(driver);
        getVehicleStatus(vehicle);

        for (Passenger passenger : passengers) {
            vehicle.BoardPassenger(passenger);
            getVehicleStatus(vehicle);
        }
        System.out.println();
    }

    public static void demonstrateTaxi() {
        TransportAbstractFactory factory = new TaxiFactory();
        processBoard(factory, 5);
    }

    public static void demonstrateBus() {
        TransportAbstractFactory factory = new BusFactory();
        processBoard(factory, 32);
    }

}
