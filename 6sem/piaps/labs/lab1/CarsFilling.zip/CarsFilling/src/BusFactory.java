public class BusFactory implements TransportAbstractFactory {

    @Override
    public Driver createDriver(String surname, String name) {
        return BusDriver.getInstance(surname, name);
    }

    @Override
    public Passenger createPassenger(String surname, String name) {
        return new Passenger(surname, name);
    }

    @Override
    public Vehicle createVehicle() {
        return new Bus();
    }
}
