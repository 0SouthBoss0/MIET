public class BusDriver extends Driver {

    private static volatile BusDriver instance;

    private BusDriver(String surname, String name) {
        super(surname, name);
    }

    public static BusDriver getInstance(String surname, String name) {
        if (instance == null) {
            synchronized (BusDriver.class) {
                if (instance == null) {
                    instance = new BusDriver(surname, name);
                }
            }
        }
        return instance;
    }

    @Override
    public String getFullName() {
        return "Водитель автобуса: " + super.getFullName();
    }
}
