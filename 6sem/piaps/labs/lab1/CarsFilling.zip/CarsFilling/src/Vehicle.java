import java.util.ArrayList;

public abstract class Vehicle {
    private Driver driver = null;
    private ArrayList<Passenger> passengers = new ArrayList<>();
    private final int capacity;

    public Vehicle(int capacity) {
        this.capacity = capacity;
    }

    abstract void BoardDriver(Driver driver);

    abstract void BoardPassenger(Passenger passenger);

    protected void setDriver(Driver driver) {
        if (!hasDriver()) {
            this.driver = driver;
        }
    }

    protected void addPassenger(Passenger passenger) {
        this.passengers.add(passenger);
    }

    boolean isFull() {
        return this.passengers.size() == capacity;
    }

    boolean hasDriver() {
        return this.driver != null;
    }
}
