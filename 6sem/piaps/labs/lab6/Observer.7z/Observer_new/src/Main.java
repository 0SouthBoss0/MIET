import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Deanery deanery = new Deanery("Деканат");
        Department prog_department = new Department("Кафедра программирования");
        Department math_department = new Department("Кафедра математики");

        deanery.registerObserver(prog_department);
        deanery.registerObserver(math_department);

        Teacher prog1 = new Teacher("Программист 1");
        Teacher prog2 = new Teacher("Программист 2");

        Teacher math1 = new Teacher("Математик 1");
        Teacher math2 = new Teacher("Математик 2");

        prog_department.registerObserver(prog1);
        prog_department.registerObserver(prog2);

        math_department.registerObserver(math1);
        math_department.registerObserver(math2);

        deanery.notifyObservers("Указ номер 1");

    }
}