import java.util.ArrayList;
import java.util.List;

class Department implements Observer, Subject {
    private final String departmentName;
    private final List<Observer> observers = new ArrayList<>();

    public Department(String name) {
        this.departmentName = name;
    }

    @Override
    public void update(String message) {
        System.out.println("Кафедра " + departmentName + " получила указ: " + message);
        notifyObservers(message);
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message + " от: " + departmentName);
        }
    }
}