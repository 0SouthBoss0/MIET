import java.util.ArrayList;
import java.util.List;

class Teacher implements Observer {
    private final String teacherName;

    public Teacher(String name) {
        this.teacherName = name;
    }


    @Override
    public void update(String message) {
        System.out.println("Преподаватель " + teacherName + " получил указ: " + message);
    }
}