import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class GraphicEditor extends JFrame {
    private final JButton buttonMode;
    private final JButton buttonColor;
    private final JTextField textMode;
    private boolean isDrawingMode;
    private final DrawingPanel drawingPanel;

    private final List<Graphic> graphics = new ArrayList<>();
    private int lastX, lastY;
    private boolean isDragging = false;
    private ImageProxy selectedProxy = null;
    private int dragOffsetX, dragOffsetY;

    private Color color = Color.BLACK;

    public GraphicEditor() {
        this.isDrawingMode = true;
        this.setTitle("Graphic Editor");
        this.setSize(800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        // Панель для кнопок
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(null);
        controlPanel.setPreferredSize(new Dimension(800, 100));

        this.buttonMode = new JButton("Переключение");
        this.buttonMode.setFont(new Font("Arial", Font.BOLD, 20));
        this.buttonMode.setBounds(0, 0, 200, 50);
        controlPanel.add(buttonMode);

        this.buttonColor = new JButton("Цвет");
        this.buttonColor.setFont(new Font("Arial", Font.BOLD, 20));
        this.buttonColor.setBounds(0, 50, 200, 50);
        controlPanel.add(buttonColor);

        this.textMode = new JTextField("Режим рисования");
        this.textMode.setFont(new Font("Arial", Font.PLAIN, 20));
        this.textMode.setHorizontalAlignment(SwingConstants.CENTER);
        this.textMode.setBounds(305, 0, 300, 50);
        this.textMode.setEditable(false);
        controlPanel.add(textMode);

        // Основная панель для рисования
        drawingPanel = new DrawingPanel();
        drawingPanel.setBackground(Color.WHITE);

        this.add(controlPanel, BorderLayout.NORTH);
        this.add(drawingPanel, BorderLayout.CENTER);

        buttonMode.addActionListener(e -> {
            this.isDrawingMode = !this.isDrawingMode;
            this.textMode.setText(isDrawingMode ? "Режим рисования" : "Режим добавления картинки");
        });

        buttonColor.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(
                    this,               // Родительское окно
                    "Выберите цвет",    // Заголовок окна
                    color              // Текущий цвет (по умолчанию)
            );
            if (newColor != null) { // Если пользователь не нажал "Отмена"
                color = newColor;   // Обновляем цвет
            }
        });

        // Обработчики событий мыши
        drawingPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    lastX = e.getX();
                    lastY = e.getY();

                    if (!isDrawingMode) {
                        for (Graphic graphic : graphics) {
                            if (graphic instanceof ImageProxy proxy) {
                                // Проверяем, попадает ли клик в границы прокси
                                if (e.getX() >= proxy.x && e.getX() <= proxy.x + proxy.getWidth() &&
                                        e.getY() >= proxy.y && e.getY() <= proxy.y + proxy.getHeight()) {
                                    selectedProxy = proxy;
                                    isDragging = true;
                                    dragOffsetX = e.getX() - proxy.x;
                                    dragOffsetY = e.getY() - proxy.y;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    isDragging = false;
                    selectedProxy = null;
                }
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    if (!isDrawingMode && e.getClickCount() == 2) {
                        graphics.clear();
                        ImageProxy proxy = new ImageProxy("img/class_diag.png", 100, 100);
                        proxy.setPosition(e.getX(), e.getY()); // Устанавливаем позицию прокси
                        graphics.add(proxy);
                        lastX = e.getX();
                        lastY = e.getY();
                        drawingPanel.repaint();
                    }
                } else if (!isDrawingMode && SwingUtilities.isRightMouseButton(e) && e.getClickCount() == 2) {
                    for (Graphic graphic : graphics) {
                        if (graphic instanceof ImageProxy proxy) {
                            if (proxy.realImage == null) {
                                proxy.loadRealImage();
                                drawingPanel.repaint();
                            }
                            break;
                        }
                    }
                }
            }
        });

        drawingPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    if (isDrawingMode) {
                        Graphics g = drawingPanel.getGraphics();
                        g.setColor(color);
                        g.drawLine(lastX, lastY, e.getX(), e.getY());
                        lastX = e.getX();
                        lastY = e.getY();
                    } else if (isDragging && selectedProxy != null) {
                        selectedProxy.setPosition(e.getX() - dragOffsetX, e.getY() - dragOffsetY);
                        drawingPanel.repaint();
                    }
                }
            }

            @Override
            public void mouseMoved(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        this.setVisible(true);
    }

    private class DrawingPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            for (Graphic graphic : graphics) {
                graphic.draw(g, lastX, lastY);
            }
        }
    }
}