import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.*;
import java.io.File;
import java.util.Iterator;

class ImageProxy implements Graphic {
    public RealImage realImage;
    private final String filename;
    public int x;
    public int y;
    private int width;
    private int height;
    private final boolean imageExists;

    public ImageProxy(String filename, int x, int y) {
        this.filename = filename;
        this.x = x;
        this.y = y;
        this.imageExists = new File(filename).exists();

        if (imageExists) {
            try {
                ImageInputStream in = ImageIO.createImageInputStream(new File(filename));
                Iterator<ImageReader> readers = ImageIO.getImageReaders(in);
                if (readers.hasNext()) {
                    ImageReader reader = readers.next();
                    reader.setInput(in);
                    this.width = reader.getWidth(0);
                    this.height = reader.getHeight(0);
                    reader.dispose();
                }
                in.close();
            } catch (Exception e) {
                System.out.println("Error reading image dimensions: " + e.getMessage());
                this.width = 100;
                this.height = 100;
            }
        } else {
            this.width = 100;
            this.height = 100;
        }
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void draw(Graphics g, int x, int y) {
        if (realImage != null) {
            realImage.draw(g, this.x, this.y);
        } else {
            if (imageExists) {
                g.setColor(Color.LIGHT_GRAY);
                g.fillRect(this.x, this.y, width, height);
                g.setColor(Color.BLACK);
                g.drawRect(this.x, this.y, width, height);
                g.drawString("Loading...", this.x + 10, this.y + 20);
            } else {
                g.setColor(Color.RED);
                g.fillRect(this.x, this.y, width, height);
                g.setColor(Color.BLACK);
                g.drawRect(this.x, this.y, width, height);
                g.drawString("Image not found", this.x + 10, this.y + 20);
            }
        }
    }

    @Override
    public int getWidth() {
        return realImage != null ? realImage.getWidth() : width;
    }

    @Override
    public int getHeight() {
        return realImage != null ? realImage.getHeight() : height;
    }

    public void loadRealImage() {
        if (realImage == null) {
            realImage = new RealImage(filename);
        }
    }
}