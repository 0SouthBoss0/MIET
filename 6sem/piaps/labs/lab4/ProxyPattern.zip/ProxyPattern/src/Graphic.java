import java.awt.*;

interface Graphic {
    void draw(Graphics g, int x, int y);
    int getWidth();
    int getHeight();
}