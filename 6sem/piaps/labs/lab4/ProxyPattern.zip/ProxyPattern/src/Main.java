
public class Main {
    public static void main(String[] args) {
        GraphicEditor graphicEditor = new GraphicEditor();
    }
}
